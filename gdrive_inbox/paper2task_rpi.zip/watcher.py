
import time
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import os
import task_ocr

WATCH_FOLDER = './gdrive_inbox'

class TarefaHandler(FileSystemEventHandler):
    def on_created(self, event):
        if not event.is_directory and event.src_path.lower().endswith(('.png', '.jpg', '.jpeg')):
            print(f"Nova imagem detectada: {event.src_path}")
            task_ocr.processar_imagem(event.src_path)

if __name__ == "__main__":
    os.makedirs(WATCH_FOLDER, exist_ok=True)
    task_ocr.init_db()
    event_handler = TarefaHandler()
    observer = Observer()
    observer.schedule(event_handler, WATCH_FOLDER, recursive=False)
    observer.start()
    print(f"Observando a pasta: {WATCH_FOLDER}")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
