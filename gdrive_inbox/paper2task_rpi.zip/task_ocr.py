
import pytesseract
from PIL import Image
import sqlite3
import os

DB_PATH = 'tarefas.db'

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS tarefas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        descricao TEXT NOT NULL,
        origem TEXT,
        status TEXT DEFAULT 'pendente',
        criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    conn.commit()
    conn.close()

def extrair_tarefas(texto):
    linhas = texto.strip().split('\n')
    return [linha.strip() for linha in linhas if linha.strip()]

def processar_imagem(imagem_path):
    texto = pytesseract.image_to_string(Image.open(imagem_path), lang='por')
    tarefas = extrair_tarefas(texto)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    for tarefa in tarefas:
        c.execute("INSERT INTO tarefas (descricao, origem) VALUES (?, ?)", (tarefa, imagem_path))
    conn.commit()
    conn.close()
    print(f"Tarefas extraídas de {imagem_path}: {tarefas}")

if __name__ == '__main__':
    init_db()
    test_image = 'teste.jpg'
    if os.path.exists(test_image):
        processar_imagem(test_image)
